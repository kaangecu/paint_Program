﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;


namespace CizimProgrami
{
    /* Public Class HexPictureBox
     Inherits PictureBox

     Protected Overrides Sub OnSizeChanged(ByVal e As System.EventArgs)
         SetRegion()
         MyBase.OnSizeChanged(e)
     End Sub

     Private Sub SetRegion()
         Dim p(5) As Point
         Dim v As Integer = CInt(Me.Width / 2 * Math.Sin(30 * Math.PI / 180))
         p(0) = New Point(Me.Width \ 2, 0)
         p(1) = New Point(Me.Width, v)
         p(2) = New Point(Me.Width, Me.Height - v)
         p(3) = New Point(Me.Width \ 2, Me.Height)
         p(4) = New Point(0, Me.Height - v)
         p(5) = New Point(0, v)
         Using gp As New Drawing2D.GraphicsPath
            gp.AddPolygon(p)
            Me.Region = New Region(gp)*/



    class HexPictureBox : PictureBox
    {
        public HexPictureBox()
        {
            this.BackColor = Color.DarkGray;
        }
        protected override void OnResize(EventArgs e)
        {            
            base.OnResize(e);
            SetRegion();             
        }

        private void SetRegion()
        {
            Point[] points = new Point[6];
            int v= Convert.ToInt32(this.Width / 2 * Math.Sin(30 * Math.PI / 180));
            points[0]= new Point (this.Width / 2, 0);
            points[1] = new Point(this.Width , v);
            points[2] = new Point(this.Width,this.Height-v);
            points[3] = new Point(this.Width / 2, this.Height);
            points[4] = new Point(0, this.Height-v);
            points[5] = new Point(0, v);



            using (var gp = new GraphicsPath())
            {
            gp.AddPolygon(points);
            this.Region = new Region(gp);
            }

        }

        public void Ciz(Panel panel, int BaslangicX, int BaslangicY, int Genislik, int Yukseklik, EventHandler tıkla, Color renk)
        {
            this.Location = new Point(BaslangicX, BaslangicY);
            panel.Controls.Add(this);
            this.BackColor = renk;
            this.Size = new Size(Genislik, Yukseklik);
            this.Click += tıkla;
        }
    }
}
