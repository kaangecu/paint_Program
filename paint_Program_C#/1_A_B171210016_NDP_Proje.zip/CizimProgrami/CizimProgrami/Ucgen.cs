﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;



namespace CizimProgrami
{
    public class TriangularPictureBox : PictureBox
    {
        protected override void OnResize(EventArgs e)
        {
            using (var gp = new GraphicsPath())
            {

                Point[] points = new Point[3];               
                points[0] = new Point(this.Width / 2, 0);
                points[1] = new Point(0, this.Height);
                points[2] = new Point(this.Width, this.Height);
               
                gp.AddPolygon(points);
                this.Region = new Region(gp);
            }
        }

        public void Ciz(Panel panel, int BaslangicX, int BaslangicY, int Genislik, int Yukseklik, EventHandler tıkla, Color renk)
        {
            this.Location = new Point(BaslangicX, BaslangicY);
            panel.Controls.Add(this);
            this.BackColor = renk;
            this.Size = new Size(Genislik, Yukseklik);
            this.Click += tıkla;
        }
    }


}

