﻿namespace CizimProgrami
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.CizimAlani = new System.Windows.Forms.Panel();
            this.buttonUcgen = new System.Windows.Forms.Button();
            this.buttonKare = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupShape = new System.Windows.Forms.GroupBox();
            this.buttonAltigen = new System.Windows.Forms.Button();
            this.buttonDaire = new System.Windows.Forms.Button();
            this.groupColors = new System.Windows.Forms.GroupBox();
            this.buttonBeyaz = new System.Windows.Forms.Button();
            this.buttonMor = new System.Windows.Forms.Button();
            this.buttonTuruncu = new System.Windows.Forms.Button();
            this.buttonSari = new System.Windows.Forms.Button();
            this.buttonSiyah = new System.Windows.Forms.Button();
            this.buttonMavi = new System.Windows.Forms.Button();
            this.buttonYesil = new System.Windows.Forms.Button();
            this.buttonKirmizi = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonSil = new System.Windows.Forms.Button();
            this.buttonSec = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.dosyaİşlemleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kaydetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kayıtlıDosyaAçToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupShape.SuspendLayout();
            this.groupColors.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // CizimAlani
            // 
            this.CizimAlani.BackColor = System.Drawing.Color.White;
            this.CizimAlani.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CizimAlani.Location = new System.Drawing.Point(11, 34);
            this.CizimAlani.Margin = new System.Windows.Forms.Padding(2);
            this.CizimAlani.Name = "CizimAlani";
            this.CizimAlani.Size = new System.Drawing.Size(839, 602);
            this.CizimAlani.TabIndex = 0;
            this.CizimAlani.Paint += new System.Windows.Forms.PaintEventHandler(this.CizimAlani_Paint);
            this.CizimAlani.MouseClick += new System.Windows.Forms.MouseEventHandler(this.CizimAlani_MouseClick);
            this.CizimAlani.MouseDown += new System.Windows.Forms.MouseEventHandler(this.CizimAlani_MouseDown);
            this.CizimAlani.MouseMove += new System.Windows.Forms.MouseEventHandler(this.CizimAlani_MouseMove);
            this.CizimAlani.MouseUp += new System.Windows.Forms.MouseEventHandler(this.CizimAlani_MouseUp);
            // 
            // buttonUcgen
            // 
            this.buttonUcgen.BackColor = System.Drawing.Color.White;
            this.buttonUcgen.FlatAppearance.BorderSize = 5;
            this.buttonUcgen.Image = ((System.Drawing.Image)(resources.GetObject("buttonUcgen.Image")));
            this.buttonUcgen.Location = new System.Drawing.Point(14, 143);
            this.buttonUcgen.Margin = new System.Windows.Forms.Padding(2);
            this.buttonUcgen.Name = "buttonUcgen";
            this.buttonUcgen.Size = new System.Drawing.Size(105, 105);
            this.buttonUcgen.TabIndex = 2;
            this.buttonUcgen.UseVisualStyleBackColor = false;
            this.buttonUcgen.Click += new System.EventHandler(this.buttonUcgen_Click);
            // 
            // buttonKare
            // 
            this.buttonKare.Image = ((System.Drawing.Image)(resources.GetObject("buttonKare.Image")));
            this.buttonKare.Location = new System.Drawing.Point(14, 18);
            this.buttonKare.Margin = new System.Windows.Forms.Padding(2);
            this.buttonKare.Name = "buttonKare";
            this.buttonKare.Size = new System.Drawing.Size(105, 105);
            this.buttonKare.TabIndex = 1;
            this.buttonKare.UseVisualStyleBackColor = true;
            this.buttonKare.Click += new System.EventHandler(this.buttonKare_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 50;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // groupShape
            // 
            this.groupShape.Controls.Add(this.buttonAltigen);
            this.groupShape.Controls.Add(this.buttonDaire);
            this.groupShape.Controls.Add(this.buttonUcgen);
            this.groupShape.Controls.Add(this.buttonKare);
            this.groupShape.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupShape.Location = new System.Drawing.Point(869, 34);
            this.groupShape.Name = "groupShape";
            this.groupShape.Size = new System.Drawing.Size(317, 258);
            this.groupShape.TabIndex = 3;
            this.groupShape.TabStop = false;
            this.groupShape.Tag = "";
            this.groupShape.Text = "Çizim Şekilleri";
            // 
            // buttonAltigen
            // 
            this.buttonAltigen.FlatAppearance.BorderSize = 5;
            this.buttonAltigen.Image = ((System.Drawing.Image)(resources.GetObject("buttonAltigen.Image")));
            this.buttonAltigen.Location = new System.Drawing.Point(138, 143);
            this.buttonAltigen.Margin = new System.Windows.Forms.Padding(2);
            this.buttonAltigen.Name = "buttonAltigen";
            this.buttonAltigen.Size = new System.Drawing.Size(105, 105);
            this.buttonAltigen.TabIndex = 4;
            this.buttonAltigen.UseVisualStyleBackColor = true;
            this.buttonAltigen.Click += new System.EventHandler(this.buttonAltigen_Click);
            // 
            // buttonDaire
            // 
            this.buttonDaire.FlatAppearance.BorderSize = 5;
            this.buttonDaire.Image = ((System.Drawing.Image)(resources.GetObject("buttonDaire.Image")));
            this.buttonDaire.Location = new System.Drawing.Point(138, 18);
            this.buttonDaire.Margin = new System.Windows.Forms.Padding(2);
            this.buttonDaire.Name = "buttonDaire";
            this.buttonDaire.Size = new System.Drawing.Size(105, 105);
            this.buttonDaire.TabIndex = 3;
            this.buttonDaire.UseVisualStyleBackColor = true;
            this.buttonDaire.Click += new System.EventHandler(this.buttonDaire_Click);
            // 
            // groupColors
            // 
            this.groupColors.Controls.Add(this.buttonBeyaz);
            this.groupColors.Controls.Add(this.buttonMor);
            this.groupColors.Controls.Add(this.buttonTuruncu);
            this.groupColors.Controls.Add(this.buttonSari);
            this.groupColors.Controls.Add(this.buttonSiyah);
            this.groupColors.Controls.Add(this.buttonMavi);
            this.groupColors.Controls.Add(this.buttonYesil);
            this.groupColors.Controls.Add(this.buttonKirmizi);
            this.groupColors.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupColors.Location = new System.Drawing.Point(869, 315);
            this.groupColors.Name = "groupColors";
            this.groupColors.Size = new System.Drawing.Size(263, 136);
            this.groupColors.TabIndex = 4;
            this.groupColors.TabStop = false;
            this.groupColors.Text = "Renkler";
            // 
            // buttonBeyaz
            // 
            this.buttonBeyaz.BackColor = System.Drawing.SystemColors.Control;
            this.buttonBeyaz.Image = ((System.Drawing.Image)(resources.GetObject("buttonBeyaz.Image")));
            this.buttonBeyaz.Location = new System.Drawing.Point(198, 76);
            this.buttonBeyaz.Name = "buttonBeyaz";
            this.buttonBeyaz.Size = new System.Drawing.Size(50, 50);
            this.buttonBeyaz.TabIndex = 8;
            this.buttonBeyaz.UseVisualStyleBackColor = false;
            this.buttonBeyaz.Click += new System.EventHandler(this.buttonBeyaz_Click);
            // 
            // buttonMor
            // 
            this.buttonMor.BackColor = System.Drawing.SystemColors.Control;
            this.buttonMor.Image = ((System.Drawing.Image)(resources.GetObject("buttonMor.Image")));
            this.buttonMor.Location = new System.Drawing.Point(138, 76);
            this.buttonMor.Name = "buttonMor";
            this.buttonMor.Size = new System.Drawing.Size(50, 50);
            this.buttonMor.TabIndex = 7;
            this.buttonMor.UseVisualStyleBackColor = false;
            this.buttonMor.Click += new System.EventHandler(this.buttonMor_Click);
            // 
            // buttonTuruncu
            // 
            this.buttonTuruncu.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTuruncu.Image = ((System.Drawing.Image)(resources.GetObject("buttonTuruncu.Image")));
            this.buttonTuruncu.Location = new System.Drawing.Point(74, 76);
            this.buttonTuruncu.Name = "buttonTuruncu";
            this.buttonTuruncu.Size = new System.Drawing.Size(50, 50);
            this.buttonTuruncu.TabIndex = 6;
            this.buttonTuruncu.UseVisualStyleBackColor = false;
            this.buttonTuruncu.Click += new System.EventHandler(this.buttonTuruncu_Click);
            // 
            // buttonSari
            // 
            this.buttonSari.BackColor = System.Drawing.SystemColors.Control;
            this.buttonSari.Image = ((System.Drawing.Image)(resources.GetObject("buttonSari.Image")));
            this.buttonSari.Location = new System.Drawing.Point(14, 76);
            this.buttonSari.Name = "buttonSari";
            this.buttonSari.Size = new System.Drawing.Size(50, 50);
            this.buttonSari.TabIndex = 5;
            this.buttonSari.UseVisualStyleBackColor = false;
            this.buttonSari.Click += new System.EventHandler(this.buttonSari_Click);
            // 
            // buttonSiyah
            // 
            this.buttonSiyah.BackColor = System.Drawing.SystemColors.Control;
            this.buttonSiyah.Image = ((System.Drawing.Image)(resources.GetObject("buttonSiyah.Image")));
            this.buttonSiyah.Location = new System.Drawing.Point(198, 19);
            this.buttonSiyah.Name = "buttonSiyah";
            this.buttonSiyah.Size = new System.Drawing.Size(50, 50);
            this.buttonSiyah.TabIndex = 4;
            this.buttonSiyah.UseVisualStyleBackColor = false;
            this.buttonSiyah.Click += new System.EventHandler(this.buttonSiyah_Click);
            // 
            // buttonMavi
            // 
            this.buttonMavi.BackColor = System.Drawing.SystemColors.Control;
            this.buttonMavi.Image = ((System.Drawing.Image)(resources.GetObject("buttonMavi.Image")));
            this.buttonMavi.Location = new System.Drawing.Point(74, 19);
            this.buttonMavi.Name = "buttonMavi";
            this.buttonMavi.Size = new System.Drawing.Size(50, 50);
            this.buttonMavi.TabIndex = 3;
            this.buttonMavi.UseVisualStyleBackColor = false;
            this.buttonMavi.Click += new System.EventHandler(this.buttonMavi_Click);
            // 
            // buttonYesil
            // 
            this.buttonYesil.BackColor = System.Drawing.SystemColors.Control;
            this.buttonYesil.Image = ((System.Drawing.Image)(resources.GetObject("buttonYesil.Image")));
            this.buttonYesil.Location = new System.Drawing.Point(138, 19);
            this.buttonYesil.Name = "buttonYesil";
            this.buttonYesil.Size = new System.Drawing.Size(50, 50);
            this.buttonYesil.TabIndex = 2;
            this.buttonYesil.UseVisualStyleBackColor = false;
            this.buttonYesil.Click += new System.EventHandler(this.buttonYesil_Click);
            // 
            // buttonKirmizi
            // 
            this.buttonKirmizi.BackColor = System.Drawing.SystemColors.Control;
            this.buttonKirmizi.Image = ((System.Drawing.Image)(resources.GetObject("buttonKirmizi.Image")));
            this.buttonKirmizi.Location = new System.Drawing.Point(14, 19);
            this.buttonKirmizi.Name = "buttonKirmizi";
            this.buttonKirmizi.Size = new System.Drawing.Size(50, 50);
            this.buttonKirmizi.TabIndex = 0;
            this.buttonKirmizi.UseVisualStyleBackColor = false;
            this.buttonKirmizi.Click += new System.EventHandler(this.buttonKirmizi_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttonSil);
            this.groupBox1.Controls.Add(this.buttonSec);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox1.Location = new System.Drawing.Point(869, 469);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(250, 142);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Şekil İşlemleri";
            // 
            // buttonSil
            // 
            this.buttonSil.Image = ((System.Drawing.Image)(resources.GetObject("buttonSil.Image")));
            this.buttonSil.Location = new System.Drawing.Point(138, 22);
            this.buttonSil.Name = "buttonSil";
            this.buttonSil.Size = new System.Drawing.Size(105, 105);
            this.buttonSil.TabIndex = 1;
            this.buttonSil.UseVisualStyleBackColor = true;
            this.buttonSil.Click += new System.EventHandler(this.buttonSil_Click);
            // 
            // buttonSec
            // 
            this.buttonSec.Image = ((System.Drawing.Image)(resources.GetObject("buttonSec.Image")));
            this.buttonSec.Location = new System.Drawing.Point(14, 22);
            this.buttonSec.Name = "buttonSec";
            this.buttonSec.Size = new System.Drawing.Size(105, 105);
            this.buttonSec.TabIndex = 0;
            this.buttonSec.UseVisualStyleBackColor = true;
            this.buttonSec.Click += new System.EventHandler(this.buttonSec_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dosyaİşlemleriToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1159, 28);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // dosyaİşlemleriToolStripMenuItem
            // 
            this.dosyaİşlemleriToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kaydetToolStripMenuItem,
            this.kayıtlıDosyaAçToolStripMenuItem});
            this.dosyaİşlemleriToolStripMenuItem.Name = "dosyaİşlemleriToolStripMenuItem";
            this.dosyaİşlemleriToolStripMenuItem.Size = new System.Drawing.Size(122, 24);
            this.dosyaİşlemleriToolStripMenuItem.Text = "Dosya İşlemleri";
            // 
            // kaydetToolStripMenuItem
            // 
            this.kaydetToolStripMenuItem.Name = "kaydetToolStripMenuItem";
            this.kaydetToolStripMenuItem.Size = new System.Drawing.Size(185, 24);
            this.kaydetToolStripMenuItem.Text = "Kaydet";
            this.kaydetToolStripMenuItem.Click += new System.EventHandler(this.kaydetToolStripMenuItem_Click);
            // 
            // kayıtlıDosyaAçToolStripMenuItem
            // 
            this.kayıtlıDosyaAçToolStripMenuItem.Name = "kayıtlıDosyaAçToolStripMenuItem";
            this.kayıtlıDosyaAçToolStripMenuItem.Size = new System.Drawing.Size(185, 24);
            this.kayıtlıDosyaAçToolStripMenuItem.Text = "Kayıtlı Dosya Aç";
            this.kayıtlıDosyaAçToolStripMenuItem.Click += new System.EventHandler(this.kayıtlıDosyaAçToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1159, 647);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupColors);
            this.Controls.Add(this.groupShape);
            this.Controls.Add(this.CizimAlani);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupShape.ResumeLayout(false);
            this.groupColors.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel CizimAlani;
        private System.Windows.Forms.Button buttonUcgen;
        private System.Windows.Forms.Button buttonKare;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox groupShape;
        private System.Windows.Forms.Button buttonAltigen;
        private System.Windows.Forms.Button buttonDaire;
        private System.Windows.Forms.GroupBox groupColors;
        private System.Windows.Forms.Button buttonBeyaz;
        private System.Windows.Forms.Button buttonMor;
        private System.Windows.Forms.Button buttonTuruncu;
        private System.Windows.Forms.Button buttonSari;
        private System.Windows.Forms.Button buttonSiyah;
        private System.Windows.Forms.Button buttonMavi;
        private System.Windows.Forms.Button buttonYesil;
        private System.Windows.Forms.Button buttonKirmizi;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonSil;
        private System.Windows.Forms.Button buttonSec;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem dosyaİşlemleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kaydetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kayıtlıDosyaAçToolStripMenuItem;
    }
}

