﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace CizimProgrami
{
    class Kare:PictureBox
    {


        public void pictBoxCiz(Panel panel,int BaslangicX, int BaslangicY, int Genislik, int Yukseklik, Color renk, EventHandler tıkla)
        {
            this.Location = new Point(BaslangicX, BaslangicY);
            panel.Controls.Add(this);
            this.BackColor = renk;
            this.Size = new Size(Genislik, Yukseklik);
            this.Click += tıkla;
        }
    }
}
