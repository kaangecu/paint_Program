﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.IO;

namespace CizimProgrami
{
    public partial class Form1 : Form
    {

        Graphics g;
        bool cizilebilir;
        int xfirst, yfirst, xlast, ylast;
        Color renk=Color.Blue;
        SolidBrush b;
        SolidBrush temiz;
        List<string> ozellikler_list = new List<string>();
        List<PictureBox> pictlist = new List<PictureBox>();
        GraphicsPath gp = new GraphicsPath();
        bool secim = false;
        bool secim_daire = false;bool secim_kare = false;bool secim_altigen = false;bool secim_ucgen = false;bool sil=false;
        Kare pict;
        PictureBox secili= new PictureBox();
        OvalPictureBox dairepict;
        HexPictureBox hexpict;
        TriangularPictureBox ucgenpict;




        public Form1()
        {
            InitializeComponent();
            g= CizimAlani.CreateGraphics();

            //KULLANILMIYOR DOUBLE BUFFERED KODU
            //timer1.Enabled = true;
            
        }

        
        //KULLANILMIYOR DOUBLE BUFFERED KODU
        private void Form1_Load(object sender, EventArgs e)
        {
            /* g = CizimAlani.CreateGraphics();
             g.Clear(Color.Purple);
             bm = new Bitmap(CizimAlani.Width, CizimAlani.Height);
             g2 = Graphics.FromImage(bm);*/
            

            
        }
        
        private void timer1_Tick(object sender, EventArgs e)
        {

            /*SolidBrush b = new SolidBrush(renk);
            SolidBrush k = new SolidBrush(Color.Blue);
            Rectangle rect = new Rectangle(xfirst, yfirst, (xlast - xfirst), (xlast - xfirst));
            if (xlast > xfirst)

             g2.FillRectangle(k, rect);

            g.DrawImage(bm, 0, 0);*/
            



        }

        private void CizimAlani_Paint(object sender, PaintEventArgs e)
        {
            //g.DrawImage(bm,0,0);
            

        }
        //KULLANILMIYOR DOUBLE BUFFERED KODU



        private void buttonSec_Click(object sender, EventArgs e)
        {
             secim = true;
            sil = false;
            secim_kare = false;
            secim_daire = false;
            secim_altigen = false;
            secim_ucgen = false;

            buttonKare.BackColor = SystemColors.Control;
            buttonDaire.BackColor = SystemColors.Control;
            buttonUcgen.BackColor = SystemColors.Control;
            buttonAltigen.BackColor = SystemColors.Control;
            buttonSec.BackColor = Color.SteelBlue;
            buttonSil.BackColor = SystemColors.Control;

        }

        private void buttonSil_Click(object sender, EventArgs e)
        {
            secim = false;
            sil = true;
            secim_kare = false;
            secim_daire = false;
            secim_altigen = false;
            secim_ucgen = false;

            buttonKare.BackColor = SystemColors.Control;
            buttonDaire.BackColor = SystemColors.Control;
            buttonUcgen.BackColor = SystemColors.Control;
            buttonAltigen.BackColor = SystemColors.Control;
            buttonSec.BackColor = SystemColors.Control;
            buttonSil.BackColor = Color.SteelBlue;

            foreach (PictureBox s in pictlist)
            {
                    b = new SolidBrush(Color.LightGreen);
                    temiz = new SolidBrush(CizimAlani.BackColor);
                    if (s.Equals(secili))
                    {
                        secili.Dispose();
                        s.Dispose();
                        g.FillRectangle(temiz, s.Left - 10, s.Top - 10, s.Width + 20, s.Height + 20);
                        pictlist.Remove(s);
                        break;

                    }



            }
        }



        private void buttonKare_Click(object sender, EventArgs e)
        {
            secimTuslariSecildi(buttonKare);

            secim_kare = true;
            secim_daire = false;
            secim = false;
            secim_altigen = false;
            secim_ucgen = false;

        }

        private void buttonDaire_Click(object sender, EventArgs e)
        {
            secimTuslariSecildi(buttonDaire);

            secim_kare = false;
            secim_daire = true;
            secim = false;
            secim_altigen = false;
            secim_ucgen = false;
        }
       
        private void buttonUcgen_Click(object sender, EventArgs e)
        {
            secimTuslariSecildi(buttonUcgen);

            secim_kare = false;
            secim_daire = false;
            secim = false;
            secim_altigen = false;
            secim_ucgen = true;
        }

        private void buttonAltigen_Click(object sender, EventArgs e)
        {
            secimTuslariSecildi(buttonAltigen);

            secim_kare = false;
            secim_daire = false;
            secim = false;
            secim_altigen = true;
            secim_ucgen = false;
        }

        


        private void kaydetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string pictbox_ozellikleri;

            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                StreamWriter sw = new StreamWriter(ofd.FileName);

                    foreach (var s in pictlist)
                    {

                    if (s.AccessibilityObject.ToString() == "ControlAccessibleObject: Owner = CizimProgrami.Kare, SizeMode: Normal")
                        pictbox_ozellikleri = "Kare";

                    else if (s.AccessibilityObject.ToString() == "ControlAccessibleObject: Owner = CizimProgrami.OvalPictureBox, SizeMode: Normal")
                        pictbox_ozellikleri = "Daire";

                    else if (s.AccessibilityObject.ToString() == "ControlAccessibleObject: Owner = CizimProgrami.TriangularPictureBox, SizeMode: Normal")
                        pictbox_ozellikleri = "Üçgen";

                    else if (s.AccessibilityObject.ToString() == "ControlAccessibleObject: Owner = CizimProgrami.HexPictureBox, SizeMode: Normal")
                        pictbox_ozellikleri = "Altıgen";

                    else return;

                    pictbox_ozellikleri +=
                        "|" + s.Location.X.ToString() +
                        "|" + s.Location.Y.ToString() +
                        "|" + s.Width.ToString() +
                        "|" + s.Height.ToString()+
                        "|" + s.BackColor.ToString().Substring(7, s.BackColor.ToString().Length-8); ;
                        sw.WriteLine(pictbox_ozellikleri);

                    }

                sw.Dispose();
            }

        }

        private void kayıtlıDosyaAçToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CizimAlani.Refresh();
            foreach (var s in pictlist)
            {
                s.Dispose();
            }
            pictlist.Clear();
            string pictbox_ozellikleri;

            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                StreamReader sr = new StreamReader(ofd.FileName);


                while ((pictbox_ozellikleri = sr.ReadLine()) != null) 
                {
                    var ozellikler = pictbox_ozellikleri.Split('|');
                    

                    switch (ozellikler[0])
                    {
                        case "Kare":
                            pict = new Kare();
                            pict.pictBoxCiz(CizimAlani,Convert.ToInt32(ozellikler[1]), Convert.ToInt32(ozellikler[2]), Convert.ToInt32(ozellikler[3]), Convert.ToInt32(ozellikler[4]), Color.FromName(ozellikler[5]), p_Click);
                            pictlist.Add(pict);
                            break;

                        case "Daire":
                            dairepict = new OvalPictureBox();
                            dairepict.Ciz(CizimAlani, Convert.ToInt32(ozellikler[1]), Convert.ToInt32(ozellikler[2]), Convert.ToInt32(ozellikler[3]), Convert.ToInt32(ozellikler[4]), p_Click, Color.FromName(ozellikler[5]));
                            pictlist.Add(dairepict);
                            break;

                        case "Üçgen":
                            ucgenpict = new TriangularPictureBox();
                            ucgenpict.Ciz(CizimAlani, Convert.ToInt32(ozellikler[1]), Convert.ToInt32(ozellikler[2]), Convert.ToInt32(ozellikler[3]), Convert.ToInt32(ozellikler[4]), p_Click, Color.FromName(ozellikler[5]));
                            pictlist.Add(ucgenpict);
                            break;

                        case "Altıgen":
                            hexpict = new HexPictureBox();
                            hexpict.Ciz(CizimAlani, Convert.ToInt32(ozellikler[1]), Convert.ToInt32(ozellikler[2]), Convert.ToInt32(ozellikler[3]), Convert.ToInt32(ozellikler[4]), p_Click, Color.FromName(ozellikler[5]));
                            pictlist.Add(hexpict);
                            break;




                        default:
                            break;
                    }
                } 

            }

        }



        private void buttonKirmizi_Click(object sender, EventArgs e)
        {
            renk = Color.Red;

            renkTuslariSecildi(buttonKirmizi);
        }

        private void buttonMavi_Click(object sender, EventArgs e)
        {
            renk = Color.Blue;

            renkTuslariSecildi(buttonMavi);
        }

        private void buttonYesil_Click(object sender, EventArgs e)
        {
            renk = Color.Green;

            renkTuslariSecildi(buttonYesil);
        }

        private void buttonSiyah_Click(object sender, EventArgs e)
        {
            renk = Color.Black;

            renkTuslariSecildi(buttonSiyah);
        }

        private void buttonSari_Click(object sender, EventArgs e)
        {
            renk = Color.Yellow;

            renkTuslariSecildi(buttonSari);
        }

        private void buttonMor_Click(object sender, EventArgs e)
        {
            renk = Color.Purple;

            renkTuslariSecildi(buttonMor);
        }

        private void buttonTuruncu_Click(object sender, EventArgs e)
        {
            renk = Color.Orange;

            renkTuslariSecildi(buttonTuruncu);
        }

        private void buttonBeyaz_Click(object sender, EventArgs e)
        {
            renk = Color.GhostWhite;

            renkTuslariSecildi(buttonBeyaz);
        }



        private void p_Click(object sender, EventArgs e)
        {
            if (secim == true)
            {
                
                /*{ p.Tag = Color.Blue; }                
                p.Refresh();*/

                foreach (var s in pictlist)
                {


                    if (secim == true)
                    {
                        
                        b = new SolidBrush(Color.LightGreen);
                        temiz = new SolidBrush(CizimAlani.BackColor);
                        if (s.Equals(sender))
                        {
                            secili = s;
                            s.BackColor = renk;
                            g.FillRectangle(b, s.Left - 10, s.Top - 10, s.Width + 20, s.Height + 20);

                        }
                        else
                        {
                            g.FillRectangle(temiz, s.Left - 10, s.Top - 10, s.Width + 20, s.Height + 20);                            
                        }

                    }

                }


            }
        }



        private void CizimAlani_MouseClick(object sender, MouseEventArgs e)
        {
                    foreach (PictureBox s in pictlist)
                    {
                        b = new SolidBrush(Color.LightGreen);
                        temiz = new SolidBrush(CizimAlani.BackColor);

                        g.FillRectangle(temiz, s.Left - 10, s.Top - 10, s.Width + 20, s.Height + 20);

                    }
            secili = null;
        }


        private void CizimAlani_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {


                if (secim_kare == true)
                    pict = new Kare();

                if (secim_daire == true)
                    dairepict = new OvalPictureBox();

                if (secim_ucgen == true)
                    ucgenpict = new TriangularPictureBox();

                if (secim_altigen == true)
                    hexpict = new HexPictureBox();



                cizilebilir = true;

                xfirst = e.X;
                yfirst = e.Y;

            }
        }

        private void CizimAlani_MouseUp(object sender, MouseEventArgs e)
        {

            if (e.Button == MouseButtons.Left)
            {

                cizilebilir = false;

                if (secim_kare == true)
                    pictlist.Add(pict);

                if (secim_daire == true)
                    pictlist.Add(dairepict);

                if (secim_ucgen == true)
                    pictlist.Add(ucgenpict);

                if (secim_altigen == true)
                    pictlist.Add(hexpict);


            }
        }


        private void CizimAlani_MouseMove(object sender, MouseEventArgs e)
        {

            xlast = e.X;
            ylast = e.Y;
            if (cizilebilir)
            {


                if (secim_kare == true)
                {
                    if(e.X <CizimAlani.Right && e.Y  < CizimAlani.Bottom)
                        pict.pictBoxCiz(CizimAlani, xfirst, yfirst, (xlast - xfirst), (ylast - yfirst), renk,p_Click);
                }

                if (secim_daire == true)
                {
                    if (//Convert.ToInt32(Math.Sqrt((yfirst + dairepict.Height) * (yfirst + dairepict.Height) + dairepict.Height / 2 * dairepict.Height / 2)) < CizimAlani.Height
                         e.X < CizimAlani.Width
                          && dairepict.Bottom < CizimAlani.Height
                        )
                   
                        dairepict.Ciz(CizimAlani, xfirst, yfirst, (xlast - xfirst), (xlast - xfirst), p_Click, renk);                    
                    //while (dairepict.Bottom == CizimAlani.Bottom && dairepict.Right == CizimAlani.Right);
                }

                if (secim_ucgen == true)
                {
                    if (e.X < CizimAlani.Width && ucgenpict.Bottom < CizimAlani.Bottom
                        )
                        ucgenpict.Ciz(CizimAlani, xfirst, yfirst, (xlast - xfirst), (xlast - xfirst), p_Click, renk);
                }

                if (secim_altigen == true)
                {
                    if (e.X < CizimAlani.Right && hexpict.Bottom < CizimAlani.Bottom)
                        hexpict.Ciz(CizimAlani, xfirst, yfirst, (xlast - xfirst), (xlast - xfirst), p_Click, renk);
                }

            }
        }


        public void renkTuslariSecildi(Button secilenTus)
        {
            buttonKirmizi.BackColor = SystemColors.Control;
            buttonMavi.BackColor = SystemColors.Control;
            buttonYesil.BackColor = SystemColors.Control;
            buttonSiyah.BackColor = SystemColors.Control;
            buttonSari.BackColor = SystemColors.Control;
            buttonTuruncu.BackColor = SystemColors.Control;
            buttonMor.BackColor = SystemColors.Control;
            buttonBeyaz.BackColor = SystemColors.Control;

            secilenTus.BackColor = Color.SteelBlue;

        }

        public void secimTuslariSecildi(Button secilenTus)
        {
            
            buttonKare.BackColor = SystemColors.Control;
            buttonDaire.BackColor = SystemColors.Control;
            buttonUcgen.BackColor = SystemColors.Control;
            buttonAltigen.BackColor = SystemColors.Control;
            buttonSec.BackColor = SystemColors.Control;
            buttonSil.BackColor = SystemColors.Control;

            secilenTus.BackColor = Color.SteelBlue;

        }
    }
}
